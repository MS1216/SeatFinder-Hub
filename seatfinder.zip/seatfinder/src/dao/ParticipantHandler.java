/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import utils.SQLUtil;

/**
 *
 * @author michp
 */
public class ParticipantHandler {
    private SQLUtil sqlUtil;
    public ParticipantHandler() {
        sqlUtil = new SQLUtil();
    }
    public int addParticipant(String pName, int pNumber, int userID){
        String cmdTemplate = "insert into Participants(pName, pNumber, userID) values('%s', %d, %d);";
        String cmd = String.format(cmdTemplate, pName, pNumber, userID);
        return sqlUtil.executeUpdate(cmd);
    }
    
}
