/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bo.Users;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.SQLUtil;

/**
 *
 * @author michp
 */
public class UserHandler {
    private SQLUtil sqlUtil;
    public UserHandler() {
        sqlUtil = new SQLUtil();
    }
    public Users login(String username, String password){
        Users usr = null;
        try {
            String cmd = String.format("select userID, name from Users where username='%s' and password='%s'", username, password);
            ResultSet rs = sqlUtil.executeQuery(cmd);
            if(rs.next()){
                //Get Info
                int userID = rs.getInt("userID");
                String name = rs.getString("name");
                usr = new Users(userID, name);
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return usr;
    }
}
