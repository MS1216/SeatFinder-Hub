/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bo;

import java.time.LocalTime;

/**
 *
 * @author michp
 */
public class Reservations {
    private int rID;
    private int uID;
    private int eID;
    private int seatID;
    private LocalTime reservationTime;

    public Reservations(int rID, int uID, int eID, int seatID, LocalTime reservationTime) {
        this.rID = rID;
        this.uID = uID;
        this.eID = eID;
        this.seatID = seatID;
        this.reservationTime = reservationTime;
    }

    public int getrID() {
        return rID;
    }

    public void setrID(int rID) {
        this.rID = rID;
    }

    public int getuID() {
        return uID;
    }

    public void setuID(int uID) {
        this.uID = uID;
    }

    public int geteID() {
        return eID;
    }

    public void seteID(int eID) {
        this.eID = eID;
    }

    public int getSeatID() {
        return seatID;
    }

    public void setSeatID(int seatID) {
        this.seatID = seatID;
    }

    public LocalTime getReservationTime() {
        return reservationTime;
    }

    public void setReservationTime(LocalTime reservationTime) {
        this.reservationTime = reservationTime;
    }
    
}
