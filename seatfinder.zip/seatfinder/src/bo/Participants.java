/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bo;

/**
 *
 * @author michp
 */
public class Participants {
    private int pID;
    private String pName;
    private int pNumber;

    public Participants(int pID, String pName, int pNumber) {
        this.pID = pID;
        this.pName = pName;
        this.pNumber = pNumber;
    }

    public int getpID() {
        return pID;
    }

    public void setpID(int pID) {
        this.pID = pID;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public int getpNumber() {
        return pNumber;
    }

    public void setpPhonenumber(int pNumber) {
        this.pNumber = pNumber;
    }
    
}
